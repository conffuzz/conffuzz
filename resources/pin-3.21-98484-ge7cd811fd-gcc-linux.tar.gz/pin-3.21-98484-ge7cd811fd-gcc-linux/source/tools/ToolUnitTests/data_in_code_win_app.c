/*
 * Copyright (C) 2012-2021 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

#include <stdio.h>

__declspec(dllexport) int main()
{
    printf("Hello, world\n");
    return 0;
}
